<?php

//connect to the database
$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "store";

	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

	// 3.  MAKE a SQL QUERY

	// make the query
	$query = "SELECT * from locations";

	
	$stores = [];
	//grab all the locations
		$results = mysqli_query($conn, $query);
	while( $loc = mysqli_fetch_assoc($results) ) {
		
		array_push($stores,$loc);
		//print_r($stores);
	}
	//return all the locations as JSON
	//tell the browser we are sending json
	header("Content_Type: application/json");
	$json = json_encode($stores);
	//print_r($json);
	if($json == false){
	$errormessage = array("error"=>json_last_error_msg());
	$json = json_encode($json);
	http_response_code(500);
	}
	echo $json;
?>