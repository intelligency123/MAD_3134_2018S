<html>
<head>
</head>
<body>
	<h1> Welcome to the Donut Shop </h1>
	
	<a href="show-products.php"> Admin Pages </a>
</body>
</html>