<?php
	//@TODO: Put your PHP logic here
	//print_r($_POST);
	//QUERY
	$name = $_POST["pname"];
	$desc = $_POST["desc"];
	$price = $_POST["price"];
	// write the code to connect to the db
		
	// 1. WHAT IS YOUR INFO?
	// 		host ? db name? db user? db password?
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "shopping";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3.  MAKE a SQL QUERY 
	
	// make the query
	$query ='INSERT INTO product(name,description,price)VALUES("'.$name.'","'.$desc.'","'.$price.'")';
	
	// 4. SEND QUERY TO DB & GET RESULTS 
	$results = mysqli_query($conn, $query);
	if($results){
		echo "okay";
	}else{
		echo "bad";
		echo mysqli_error($conn);
		
	}
	

?>
<!DOCTYPE html5>
<html>
<head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
	<style type="text/css">
		.mdl-grid {
			max-width:1024px;
			margin-top:40px;
		}
		
		h1 {
			font-size:36px;
		}
		h2 {
			font-size:30px;
		}
	</style>

</head>
<body>

	<div class="mdl-grid">
	  <div class="mdl-cell mdl-cell--12-col">
		<p> Put some messages here? </p>
		
		<a href="show-products.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			< Go Back 
		</a>
	  </div>
	</div>
	
</body>
</html>