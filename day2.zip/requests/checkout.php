<html>
<head>
</head>
<body>
<h1>checkout </h1>
<form action="next.php" method="POST">
   FirstName: <input type="text" name="firstName"><br>
   LastName: <input type="text" name="lastname"><br>
    Email: <input type="text" name="email"><br>
	 Credit Card Number:<br> <input type="text" name="cardno"><br>
   <button type="submit">Submit</button>
</form>
</body>
</html>