<h1>hello</h1>

<?php
//get and post
//print_r($_SERVER);
//echo "you came with a post";
	echo "whats in the post? <br>";
print_r($_POST);
if($_SERVER["REQUEST_METHOD"] == "POST"){
	//post
	
echo "student name :".$_POST["studentName"]."<br>";
echo "student id :".$_POST["studentID"]."<br>";
}
echo "whats in the Get? <br>";
print_r($_GET);
 if($_SERVER["REQUEST_METHOD"] == "GET"){
	//GET
	echo "you came with a Get";
	
echo "student name :".$_GET["studentName"]."<br>";
echo "student id :".$_GET["studentID"]."<br>";
}
//how to get stuff that send in the form


?>