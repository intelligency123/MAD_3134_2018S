<p>check credit card</p>
<?php
$cc ="4537339827500014";
echo "credit card no.".$cc." <br>";
//if 16 digits
if(strlen($cc)==16){
	
	//reverse the string
	$reversed = strrev($cc);
	echo "reverse:".$reversed."<br>";
	//1.loop through the number in the cc
	$total =0;
	for($i=0;$i<16;$i++){
		echo $reversed[$i]."<br>";
	
	
	//2.if position  = odd
	//2a.multiply by 2
	//2b.if multiply >9 then convert otherwise do nothing
	if($i%2==1){
		$num = $reversed[$i]*2;
		if($num>9){
			$num = $num - 9;
		}
	}else{
		$num = $reversed[$i];
	}
	//echo "converted no.:".$num."<br>";
	//3.add to the total
	$total = $total+$num;
}
	
	
	//after looping do total%10
	if($total%10==0){
		echo "valid credit card";
	}else{
		echo "invalid card";
	}
	//if total%10 == 0,card valid
	
	
	
	
	
	
	
	
}else{
	echo"your credit card is not 16 digits <br>";
}
?>