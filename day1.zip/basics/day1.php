
<h1>php basics</h1>
<?php
//your code goes here
/*comments*/
$x = 30;
$y = "kamal";
$z = 40.9;
$j = $x;
//output to screen
echo $x;
echo "<h2 style='color:blue'>hi<h2>";
echo "hello"."\ngoodmorning"." <br>";
echo $x +$z;
//if statements
$a = 30;
if($a>10){
	echo "hello <br>";
}else{
	echo "bye";
}
//for loop
for($i = 0;$i<5;$i++){
	echo"hi <br>";
}
//while loop
$u = 4;
while($u<9){
	echo "hello <br>";
	$u++;
}
//function -- creating a function
function sayhello(){
	echo "ABACAXI <br>";
}
function fruit($name){
	if($name == "gujrati"){
		echo "ANANAS";
	}
	else if($name == "malayalam"){
		echo "KAITHACHAKA";
	}
	else if($name == "br"){
		echo "ABACAXI <br>";
	}
	else if($name == "viet"){
		echo "DUA";
	}
	
}
//using a function
$r = 5;


fruit("br");
//arrays
//create array
$animals = [];
$animala = array();
//add array
$animals[0] = "dog";
//another way to add to array
array_push($animals,"fox");
for($j=4;$j<10;$j++){
	array_push($animals,"cow");
}
echo "length of array ".count($animals);
for($j=0;$j<count($animals);$j++){
	echo("hello".$animals[$j]."<br>");
}
//clear array
//$animals = [];
//array output
print_r($animals);
//associate array
$easy = array(
"en" => "easy",
"fr" => "facile",
"vt" => "de",
"br" => "facil",
"my" => "elupm",
"gu" => "saral",
"pu" => "sokha"
);
print_r($easy);
echo $easy["my"]."<br>";
//looping through an associate array
foreach($easy as $k => $v){
	echo "key is :".$k ."<br>";
	echo "value is :".$v ."<br>";
	echo "-----"."<br>";
	
	
	
}


?>
