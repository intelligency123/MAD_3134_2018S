<?php
include("header.php");

	// 1. WHAT IS YOUR INFO?
	// 		host ? db name? db user? db password?
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "store";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3.  MAKE a SQL QUERY 
	
	// make the query
	$query = "SELECT * from product";
	
	// 4. SEND QUERY TO DB & GET RESULTS 
	$results = mysqli_query($conn, $query);
?>
<section class="section">
      <div class="container">
        <h1 class="title has-text-centered">Menu</h1>
        <h2 class="subtitle has-text-centered">
          A selection of awesome Donuts.
        </h2>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <!-- put your products in here -->
	<div class="columns">
		<?php
		while( $product = mysqli_fetch_assoc($results) ) {
				echo'<div class="column">';
		echo'<img src="images/cream-donut.jpg"><br>';
		echo'<p>'.$product["name"].'</p>';
		echo '<p>'.$product["product_desc"].'</p>';
		echo '<p>$'.$product["price"].'</p>';
		echo '<button class="button is-info is-outlined">Add To Cart</button>';
		echo '</div>';
		}
		?>
		</div>
      </div>
    </section>



    </script>
  </body>
</html>