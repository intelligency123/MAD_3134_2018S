<?php
	//@TODO: Put your PHP logic here
	    //seperate get and post request
	if($_SERVER["REQUEST_METHOD"]== "GET"){
		//1.write code for get requets
		$id = $_GET["id"];

	// 1. WHAT IS YOUR INFO?
	// 		host ? db name? db user? db password?
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "store";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3.  MAKE a SQL QUERY 
	$query = "SELECT * from product where id=" . $id;
	
	$results = mysqli_query($conn, $query);
	$product = mysqli_fetch_assoc($results);
	}else if($_SERVER["REQUEST_METHOD"]== "POST"){
		//2.write code for post request
		//$id = $_GET["id"];
		
		$id = $_POST["id"];

	// 1. WHAT IS YOUR INFO?
	// 		host ? db name? db user? db password?
	$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "store";
	
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
	
	// 3.  MAKE a SQL QUERY 
	$query = "DELETE FROM product where id =".$id;
	
    // $query1 = "SELECT * from product where id=" . $id;
	$results = mysqli_query($conn, $query);
	
	if($results){
		header("Location:show-products.php");
	}else{
		echo "bad";
	}
	}
	
	//echo $product["name"];
	//	print_r($product);
	
	
?>
<!DOCTYPE html5>
<html>
<head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
	<style type="text/css">
		.mdl-grid {
			max-width:1024px;
			margin-top:40px;
		}
		
		h1 {
			font-size:36px;
		}
		h2 {
			font-size:30px;
		}
	</style>

</head>
<body>

	<div class="mdl-grid">
	  <div class="mdl-cell mdl-cell--12-col">
	  	<h1> Delete Product </h1>
		<h2> Are you sure you want to delete the product? </h2>
		<h3>Product Name : <?php echo $product["name"]; ?></h3>
		<h3>Description : <?php echo $product["product_desc"]; ?></h3>
		<h3>Price : <?php echo $product["price"]; ?></h3>

		<!-- form -->
		<!-- @TODO: Update your form action/method here -->
		<form action="delete-product.php" method="POST">
		<input name="id" class="mdl-textfield__input" type="text" id="sample3" value="<?php echo $id;?>" hidden = "true">
			
			<br>
				  
		  <!-- @TODO: Update the link  -->
		  <button  class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent">
			Yes
		  </button>
		 
		</form>
		
		<br>
		
		<a href="show-products.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			 No
		</a>
	  </div>
	</div>
	
</body>
</html>