<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="title">
     Checkout
      </h1>
      <p class="subtitle">
       Fill in the form field below
      </p>
	  <form method="POST" action="confirmation.php">
	  <div class="field">
  <label class="label">Name</label>
  <div class="control has-icons-left" >
    <input class="input" type="text" placeholder="Enter your name" name="firstname">
	<span class="icon is-small is-left">
      <i class="fas fa-user"></i>
    </span>
  </div>
</div>

 <div class="field  ">
  <label class="label">Email</label>
  <div class="control has-icons-left">
    <input class="input" type="text" placeholder="enter email" name="email">
	 <span class="icon is-small is-left">
      <i class="fas fa-envelope"></i>
    </span>
	
  </div>
</div>

 <div class="field">
  <label class="label">Credit Card </label>
  <div class="control has-icons-left">
    <input class="input" type="text" placeholder="Enter your credit card" name="creditcard">
	 <span class="icon is-small is-left">
    <i class="fas fa-credit-card"></i>
    </span>
  </div>
</div>


<div class="field is-grouped">
  <div class="control">
    <button class="button is-link">Submit</button>
  </div>
 
	 
    </div>
	 <a href="confirmation.php" > Go Forward </a>
  </section>
  </form>
  </body>
</html>

