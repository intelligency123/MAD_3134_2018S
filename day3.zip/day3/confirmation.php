




<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="title">
       order confirmation
	   
      </h1>
	  <?php
//logic
print_r($_POST);
//TEST FOR ERROR CONDITION
$cc = $_POST["creditcard"] ;
$name = $_POST["firstname"] ;
$email = $_POST["email"] ;
echo $cc;
//$cc = $_POST["cc"];

//1.CHECK IF FEILD ARE BLANK

if(empty($name) || empty($email) ||empty($cc) ){
	echo "fields are blank";
	return;
}
//2.CHECK IF THE CREDIT CARD VALID
//if(ccvalid($cc) == false){
//	echo "credit card is invalid";
//}else if (ccvalid($cc) == true){
//	echo "credit card is valid";
//}

//2A.CHECK IF CARD IS 16 DIGIT
if(strlen($cc) != 16){
	echo "credit card must be of 16 digits";
	return;
}else if(ccvalid($cc) == false){
	echo "credit card is invalid";
	return;
}
//2B.DOES CC PASS THE ALGORITHIM
function ccvalid($cc){
	//algo start
	
	$reversed = strrev($cc);
		
		// 1. loop through the numbers in the cc
		$total = 0;
		
		
		for ($i=0; $i< 16; $i++) {
			// @debug: print out each character

			if ($i % 2 == 1) {
				// do multiply + convert
				$num = $reversed[$i] * 2;
				if ($num > 9) {
					//conversion
					$num = $num - 9;
				}
			}
			else {
				//do nothing
				$num = $reversed[$i];
			}
			
			
			// 3. add to the total!
			$total = $total + $num;
		
		} // end for loop
					
		// 4. after looping, do total % 10
		if ($total % 10 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	//algo end
	


//IF ALL CONDITION PASS,THEN SHOE SUCCESS MESSAGE
if(ccvalid == true){
echo "Hey".$name ."!<br>" ;
echo "Thanks for your order <br>";
echo "we send copy of your receipt on :".$email;
}

?>

      <a href="checkout.php" > Go Back </a>
    </div>
  </section>
  </body>
</html>