 <?php
  $file = file_get_contents("simplewords.txt",true);
 $words = str_word_count($file,1);
  $length = count($words);
$pick =[];
$choices = [];
 if($_SERVER["REQUEST_METHOD"] == "GET"){
	
for($i=0;$i<10;$i++){


	$randomnumber = rand(0,$length-1);
if(in_array($randomnumber,$pick) == true){
	//skip
	//continue;
}else{
	array_push($choics,$words[$randomnumber]);
	//break;
}

//echo $words[$randomnumber]."<br>";
}
//pick password
//option 1. $x = rand(00,count($choices)-1)
//option 2. $x = rand(0,1);
$x = rand(0,count($choices)-1);
$password = $choices[$x];
for($j=0;$j<count[$choices];$j++){
	echo $simplewords[$randomnumber]."<br>";
}
echo "password :". $password ."<br>";
 }
else if($_SERVER["REQUEST_METHOD"] == "POST"){
	$guess = $_POST["guess"];
	echo $guess ."<br>";
	if($guess == $password){
		echo "winner";
	}else{
		$correct = 0;
		for($i = 0;$i<4;$i++){
			if($guess[$i]==$password[$i]){
				$correct = $correct+1;
			}
		}
	}
 }
 //read words from file

 //print_r($words);
 //randomly pick words from array
//print_r( array_rand($words,10));


 ?>
 <html>
 <head></head>
 <body>
 <form>
 <input type="text" name="guess">
 <button>go</button>
 </form>
 </body>
 
 </html>
 
 